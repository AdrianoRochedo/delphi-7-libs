//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("ZParse.res");
USEPACKAGE("vcl40.bpi");
USEUNIT("..\..\src\parse\ZTokenizer.pas");
USEUNIT("..\..\src\parse\ZParseCore.pas");
USEUNIT("..\..\src\parse\ZParseIntfs.pas");
USEUNIT("..\..\src\parse\ZParseToken.pas");
USEUNIT("..\..\src\parse\ZRegExp.pas");
USEUNIT("..\..\src\parse\ZParseChars.pas");
USEPACKAGE("ZCore.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------

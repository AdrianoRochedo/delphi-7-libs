//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("ZParseSQL.res");
USEPACKAGE("vcl40.bpi");
USEUNIT("..\..\src\parsesql\ZSybaseToken.pas");
USEUNIT("..\..\src\parsesql\ZGenericSqlToken.pas");
USEUNIT("..\..\src\parsesql\ZInterbaseToken.pas");
USEUNIT("..\..\src\parsesql\ZMySqlSelectParser.pas");
USEUNIT("..\..\src\parsesql\ZMySqlToken.pas");
USEUNIT("..\..\src\parsesql\ZPostgreSqlToken.pas");
USEUNIT("..\..\src\parsesql\ZSelectSchema.pas");
USEUNIT("..\..\src\parsesql\ZGenericSelectParser.pas");
USEUNIT("..\..\src\parsesql\ZSybaseSelectParser.pas");
USEUNIT("..\..\src\parsesql\ZInterbaseSelectParser.pas");
USEUNIT("..\..\src\parsesql\ZPostgreSqlSelectParser.pas");
USEUNIT("..\..\src\parsesql\ZSybaseAnalyser.pas");
USEUNIT("..\..\src\parsesql\ZGenericSqlAnalyser.pas");
USEUNIT("..\..\src\parsesql\ZInterbaseAnalyser.pas");
USEUNIT("..\..\src\parsesql\ZMySqlAnalyser.pas");
USEUNIT("..\..\src\parsesql\ZPostgreSqlAnalyser.pas");
USEPACKAGE("ZParse.bpi");
USEPACKAGE("ZCore.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
